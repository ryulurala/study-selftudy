# Blender Shortcut VUr

With this Blender addon you can display mouse and keyboard input

### Installation Instructions

- Download the **shortcut_VUr-master.zip** file from Jayanam's Github https://github.com/jayanam/shortcut_VUr (Press green button top right corner).
- In Blender 2.8 go to **Edit** > **Add-ons** and on the right side of that window click on **Install** button.
- In pop-up window navigate to where you downloaded the **shortcut_VUr-master.zip** file, select it and click **Install Add-on from File...** button on top right corner.
- Back in the **Add-ons** preferences window search for **Object: Shortcut VUr** check the checkbox next to it and click **Save Preferences** button if you want to be able to see it on any new Blender projects you open. 
- Back in your **3D Viewport** (Shift + F5), On the right side of the 3D Viewport you will see a vertical tab called **Shortcut VUr**, click on it and then press **Start Shortcut VUr** button to start seeing the mouse clicks and the keys you press on your keyboard on the lower left side of your screen. 




